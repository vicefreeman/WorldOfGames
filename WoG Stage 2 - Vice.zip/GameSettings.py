# Here I will store the Global Variables
global game_difficulty
global user_name
